import { Component, OnInit, VERSION } from '@angular/core';

@Component({
  selector: 'app-login-component',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  
  name = 'Angular ' + VERSION.major;
  title = 'Lista de Heroes';
  myHero = 'Batman';
  email: string = '';
  password: string  = '';

  constructor() { }

  ngOnInit() {
  }

  login() {
    console.log(this.email);
    console.log(this.password);
  }

}
