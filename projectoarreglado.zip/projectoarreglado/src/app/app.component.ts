import { Component, VERSION } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  // name = 'Angular ' + VERSION.major;
  // title = 'Lista de Heroes';
  // myHero = 'Batman';
  // email: string = '';
  // password: string  = '';

  // login() {
  //   console.log(this.email);
  //   console.log(this.password);
  // }
}

// @Component({
//   selector: 'my-dbcx',
//   templateUrl: './dbcx/dbcx.component.html',
//   styleUrls: ['./dbcx/dbcx.component.css'],
// })
// export class dbcxComponent {}